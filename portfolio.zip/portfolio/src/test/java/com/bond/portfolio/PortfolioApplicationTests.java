package com.bond.portfolio;

import com.bond.endpoints.BondController;
import com.bond.endpoints.PortfolioController;
import com.bond.entities.Bond;
import com.bond.entities.User;
import com.bond.repository.BondRepository;
import com.bond.repository.UserRepository;
import com.bond.requests.BondRequest;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.hateoas.mediatype.hal.Jackson2HalModule;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = PortfolioApplication.class)
class PortfolioApplicationTests {
	private static String PRODUCT_SERVICE_URL =
			"http://127.0.0.1:8080/api/bond";
	@Autowired
	UserRepository userRepository;

	@Autowired
	BondRepository bondRepository;

	@Autowired
	BondController bondController;

	@Autowired
	PortfolioController portfolioController;

	@Test
	void contextLoads() {
		Assert.assertNotNull(bondController);
		Assert.assertNotNull(portfolioController);
	}

	@Test
	public void testUser() {
		User user = userRepository.findByUserId("tarun");
		Assert.assertNotNull(user);
	}

	@Test
	public void postBond() {
		BondRequest bondRequest = new BondRequest();
		bondRequest.setDescription("Mumbai Gold");
		bondRequest.setAvgReturn(5);
		bondRequest.setProfitPre(12);
		bondRequest.setUserId("tarun");
		bondRequest.setBondName("mumgold");
		bondRequest.setPricing(1200);
		try {
			RestTemplate restTemplate = restTemplate();
			ResponseEntity<Bond> response = restTemplate.postForObject(PRODUCT_SERVICE_URL, bondRequest, ResponseEntity.class);
			Assert.assertNotNull(response.getBody());
			System.out.println(response.getBody().getId());
		} catch (Exception e) {

		}
	}

	private RestTemplate restTemplate() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
				false);
		mapper.registerModule(new Jackson2HalModule());
		MappingJackson2HttpMessageConverter converter =
				new MappingJackson2HttpMessageConverter();
		converter.setSupportedMediaTypes(
				MediaType.parseMediaTypes("application/hal+json"));
		converter.setObjectMapper(mapper);
		return new RestTemplate(Arrays.asList(converter));
	}
}

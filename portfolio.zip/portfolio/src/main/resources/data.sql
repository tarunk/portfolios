insert into user (id, email, name, role, user_name) values(1,'abc@xyg.com', 'tarun', 'ADMIN', 'tarun');
insert into user (id, email, name, role, user_name) values(2,'abcd@xyg.com', 'barun', 'CUSTOMER', 'barun');
insert into user (id, email, name, role, user_name) values(3,'tonu@xyg.com', 'tonu', 'CUSTOMER', 'tonu');
insert into user (id, email, name, role, user_name) values(4,'monu@xyg.com', 'monu', 'CUSTOMER', 'monu');
insert into user (id, email, name, role, user_name) values(5,'annu@xyg.com', 'annu', 'CUSTOMER', 'annu');
insert into user (id, email, name, role, user_name) values(6,'sonu@xyg.com', 'sonu', 'SELLER', 'sonu');
insert into user (id, email, name, role, user_name) values(7,'arun@xyg.com', 'arun', 'SELLER', 'arun');


INSERT INTO bond (id, bond_name, description, price, avg_return, profit_prediction) VALUES(1, 'silver200', 'Silevr 200', 1000.00, 10.0, 5);
INSERT INTO bond (id, bond_name, description, price, avg_return, profit_prediction) VALUES(2, 'gold200', 'gold 200', 2000.00, 12.0, 15);
INSERT INTO bond (id, bond_name, description, price, avg_return, profit_prediction) VALUES(3, 'gold24', 'gold 24', 3000.00, 15.0, 25);

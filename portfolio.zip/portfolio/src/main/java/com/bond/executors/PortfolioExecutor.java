package com.bond.executors;


import com.bond.entities.*;
import com.bond.repository.*;
import com.bond.services.BuyRequestManager;
import com.bond.services.SaleRequestManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Engine which do buying and selling when request matches
 */
@Component
@Scope("prototype")
public class PortfolioExecutor implements Runnable {
    Logger logger = LoggerFactory.getLogger(PortfolioExecutor.class);
    @Autowired
    private BuyRequestManager buyRequestManager;

    @Autowired
    private SaleRequestManager saleRequestManager;

    @Autowired
    private BuyerRepository buyerRepository;

    @Autowired
    private SellerRepository sellerRepository;

    @Autowired
    private SalesInfoRepository salesInfoRepository;

    @Autowired
    private CustomerPortfolioRepository customerPortfolioRepository;

    @Autowired
    private BondOwnerRepository bondOwnerRepository;

    private SalesInfo getSalesInfo(int sales, SellerRequest sellerRequest, BuyerRequest buyerRequest) {
        return new SalesInfo(sellerRequest.getBondName(),
                buyerRequest.getBuyer(),
                sellerRequest.getSeller(),
                sales,
                sellerRequest.getSellPrice());
    }

    private CustomerPortfolio getCustomerPortfolio(int buy, SellerRequest sellerRequest, BuyerRequest buyerRequest) {
        return new CustomerPortfolio(buyerRequest.getBuyer(),
                sellerRequest.getSeller(),
                sellerRequest.getBondName(),
                buy,
                sellerRequest.getSellPrice());
    }
    private BondOwner getBondOwner(int buy, String owner, String bondName) {
        return new BondOwner(owner, bondName, buy);
    }
    @Override
    public void run() {
        logger.info("I am running - " + Thread.currentThread().getName());
        BuyerRequest buyerRequest = buyRequestManager.poll();
        if (buyerRequest != null) {
            SellerRequest sellerRequest = saleRequestManager.pop(buyerRequest);
            while (sellerRequest != null && buyerRequest.getCount() > 0) {
                int buy = 0;
                if (sellerRequest.getCount() < buyerRequest.getCount()) {
                    buy = sellerRequest.getCount();
                } else {
                    buy = buyerRequest.getCount();
                }

                BondOwner bondOwner = bondOwnerRepository.get(buyerRequest.getBuyer(), buyerRequest.getBondName());
                if (bondOwner == null) {
                    bondOwnerRepository.add(getBondOwner(buy, buyerRequest.getBuyer(), buyerRequest.getBondName()));
                } else {
                    bondOwner.setCount(bondOwner.getCount() + buy);
                    bondOwnerRepository.update(bondOwner);
                }

                salesInfoRepository.add(getSalesInfo(buy, sellerRequest, buyerRequest));
                customerPortfolioRepository.add(getCustomerPortfolio(buy, sellerRequest, buyerRequest));
                buyerRequest.setCount(buyerRequest.getCount() - buy);
                sellerRequest.setCount(sellerRequest.getCount() - buy);

                if (sellerRequest.getCount() == 0) {
                    sellerRequest.setStatus("COMPLETED");
                }

                if (buyerRequest.getCount() == 0) {
                    buyerRequest.setStatus("COMPLETED");
                }
                if (!sellerRequest.getStatus().equals("COMPLETED")) {
                    saleRequestManager.add(sellerRequest);
                }
                buyerRepository.update(buyerRequest);
                sellerRepository.update(sellerRequest);

                sellerRequest = saleRequestManager.pop(buyerRequest);
            }
            if (buyerRequest.getCount() > 0) {
                buyRequestManager.add(buyerRequest);
            }

            if (sellerRequest != null && sellerRequest.getCount() > 0) {
                saleRequestManager.add(sellerRequest);
            }
        }
    }
}

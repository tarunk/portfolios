package com.bond.services;

import com.bond.executors.PortfolioExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class BuyRequestExecutor {
    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    ThreadPoolTaskScheduler threadPoolTaskScheduler;

    @PostConstruct
    public void executeAsynchronously() {
        PortfolioExecutor portfolioExecutor = applicationContext.getBean(PortfolioExecutor.class);
        threadPoolTaskScheduler.scheduleAtFixedRate(portfolioExecutor, 5000);
    }
}

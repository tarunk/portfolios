package com.bond.services;

import com.bond.entities.BuyerRequest;
import org.springframework.stereotype.Service;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * keep buyer request in queue
 */
@Service
public class BuyRequestManager {
    private BlockingQueue<BuyerRequest> buyRequests;

    public BuyRequestManager() {
        buyRequests = new LinkedBlockingQueue<>();
    }

    public void add(BuyerRequest buyRequest) {
        buyRequests.add(buyRequest);
    }

    public BuyerRequest poll() {
        if (!buyRequests.isEmpty()) {
            return buyRequests.poll();
        }
        return null;
    }
}

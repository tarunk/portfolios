package com.bond.services;

import com.bond.entities.BuyerRequest;
import com.bond.entities.SellerRequest;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Keeps sales request in queue
 */
@Service
public class SaleRequestManager {
    private ConcurrentHashMap<String, ConcurrentLinkedQueue<SellerRequest>> sales;

    public SaleRequestManager() {
        sales = new ConcurrentHashMap<>();
    }

    public void add(SellerRequest sellerRequest) {
        if (sales.containsKey(sellerRequest.getBondName())) {
            ConcurrentLinkedQueue<SellerRequest> queue = sales.get(sellerRequest.getBondName());
            queue.add(sellerRequest);
        } else {
            ConcurrentLinkedQueue<SellerRequest> queue = new ConcurrentLinkedQueue<>();
            queue.add(sellerRequest);
            sales.put(sellerRequest.getBondName(), queue);
        }
    }

    public SellerRequest pop(BuyerRequest buyerRequest) {
        if (sales.containsKey(buyerRequest.getBondName())) {
            ConcurrentLinkedQueue<SellerRequest> queue = sales.get(buyerRequest.getBondName());
            if (!queue.isEmpty()) {
                return queue.poll();
            }
        }
        return null;
    }
}

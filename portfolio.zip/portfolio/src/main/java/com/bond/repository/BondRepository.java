package com.bond.repository;

import com.bond.entities.Bond;
import com.bond.requests.BondRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class BondRepository {
    Logger logger = LoggerFactory.getLogger(BondRepository.class);
    @Autowired
    EntityManager entityManager;

    @Transactional
    public Bond add(BondRequest bondRequest) {
        Bond bond = new Bond(bondRequest);
        entityManager.persist(bond);
        return bond;
    }

    @Transactional
    public Bond update(BondRequest bondRequest) {
        TypedQuery<Bond> query = null;
        try {
            query = entityManager.createQuery("SELECT B FROM Bond B WHERE B.bondName = :bondName", Bond.class);
            query.setParameter("bondName", bondRequest.getBondName());

            Bond bond = query.getSingleResult();
            if (bond != null) {
                bond.setAvgReturn(bondRequest.getAvgReturn());
                bond.setProfitPrediction(bondRequest.getProfitPre());
                bond.setPrice(bondRequest.getPricing());
                entityManager.merge(bond);
                return bond;
            }
        } catch(Exception e) {
            logger.error(e.getMessage());
        }
        return null;
    }

    @Transactional
    public Bond delete(String bondName) {
        TypedQuery<Bond> query = entityManager.createQuery("SELECT B FROM Bond B WHERE B.bondName = :bondName", Bond.class);
        query.setParameter("bondName", bondName);

        Bond bond = query.getSingleResult();
        if (bond == null) {
            return bond;
        }
        entityManager.remove(bond);
        return bond;
    }

    public List<Bond> getBond(String customerName) {
        Query query = entityManager.createNativeQuery("SELECT * FROM bond B WHERE B.bond_name IN (SELECT DISTINCT bond_name FROM customer_portfolio WHERE buyer_name = :customerName)", Bond.class);
        query.setParameter("customerName", customerName);
        List<Bond> list = query.getResultList();
        return list;
    }

    public Bond get(String bondName) {
        TypedQuery<Bond> query = null;
        try {
            query = entityManager.createQuery("SELECT B FROM Bond B WHERE B.bondName = :bondName", Bond.class);
            query.setParameter("bondName", bondName);
            Bond bond = query.getSingleResult();
            if (bond != null) {
                return bond;
            }
        } catch (Exception e) {
            System.out.println(e.getStackTrace().toString());
        }

        return null;
    }
}

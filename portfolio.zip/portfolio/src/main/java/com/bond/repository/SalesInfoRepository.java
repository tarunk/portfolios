package com.bond.repository;

import com.bond.entities.SalesInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.List;

@Repository
public class SalesInfoRepository {
    @Autowired
    private EntityManager entityManager;

    @Transactional
    public SalesInfo add(SalesInfo salesInfo) {
        entityManager.persist(salesInfo);
        return salesInfo;
    }

    public List<SalesInfo> getSellers(String seller) {
        TypedQuery<SalesInfo> query = entityManager.createQuery("SELECT S FROM SalesInfo S WHERE S.seller = :seller", SalesInfo.class);
        query.setParameter("seller", seller);
        return query.getResultList();
    }
    public List<SalesInfo> getSalesReport(String frequency) {
        LocalDateTime dtime = LocalDateTime.now();
        LocalDateTime start = null;
        LocalDateTime end = null;
        if (frequency.equals("monthly")) {
            start = dtime.withDayOfMonth(1);
            end = dtime.withDayOfMonth(dtime.getMonth().maxLength());
        } else {
            start = dtime.withDayOfYear(1);
            end = dtime.withDayOfYear(dtime.getDayOfYear());
        }
        TypedQuery<SalesInfo> query = entityManager.createQuery("SELECT S FROM SalesInfo S WHERE S.created >= :start and S.created <= :end", SalesInfo.class);
        query.setParameter("start", start);
        query.setParameter("end", end);

        return query.getResultList();
    }

}

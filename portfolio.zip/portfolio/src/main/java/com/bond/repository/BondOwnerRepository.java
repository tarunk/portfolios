package com.bond.repository;

import com.bond.entities.BondOwner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

@Repository
public class BondOwnerRepository {
    Logger logger = LoggerFactory.getLogger(BondOwnerRepository.class);
    @Autowired
    private EntityManager entityManager;

    public BondOwner get(String ownerName, String bondName) {
        TypedQuery<BondOwner> query = null;
        try {
            query = entityManager.createQuery("SELECT B FROM BondOwner B WHERE B.owner = :ownerName and B.bondName = :bondName", BondOwner.class);
            query.setParameter("ownerName", ownerName);
            query.setParameter("bondName", bondName);
            BondOwner bondOwner = query.getSingleResult();
            if (bondOwner != null) {
                return bondOwner;
            }
        } catch(Exception e){
           logger.error(e.getMessage());
        }
        return null;
    }

    @Transactional
    public BondOwner add(BondOwner bondOwner) {
        entityManager.persist(bondOwner);
        return bondOwner;
    }

    @Transactional
    public BondOwner update(BondOwner bondOwner) {
        if (bondOwner.getCount() == 0) {
            entityManager.remove(bondOwner);
            return bondOwner;
        }
        return entityManager.merge(bondOwner);
    }

}

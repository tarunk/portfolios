package com.bond.repository;

import com.bond.entities.BuyerRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class BuyerRepository {
    @Autowired
    EntityManager entityManager;

    @Transactional
    public BuyerRequest add(BuyerRequest buyerRequest) {
        entityManager.persist(buyerRequest);
        return buyerRequest;
    }

    @Transactional
    public BuyerRequest update(BuyerRequest buyerRequest) {
        entityManager.merge(buyerRequest);
        return buyerRequest;
    }

    public List<BuyerRequest> getBuyerRequest(String bondName) {
        TypedQuery<BuyerRequest> query = entityManager.createQuery("SELECT B FROM BuyerRequest B WHERE B.bondName = :bondName", BuyerRequest.class);
        query.setParameter("bondName", bondName);
        List<BuyerRequest> list = query.getResultList();

        return list;
    }
}

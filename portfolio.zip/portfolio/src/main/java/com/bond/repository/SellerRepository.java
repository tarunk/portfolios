package com.bond.repository;

import com.bond.entities.SellerRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class SellerRepository {
    @Autowired
    EntityManager entityManager;

    @Transactional
    public SellerRequest add(SellerRequest sellerRequest) {
        entityManager.persist(sellerRequest);
        return sellerRequest;
    }

    @Transactional
    public SellerRequest update(SellerRequest sellerRequest) {
        SellerRequest sellerRequest1 = entityManager.merge(sellerRequest);
        return sellerRequest1;
    }

    public List<SellerRequest> getSellerRequest(String bondName) {
        TypedQuery<SellerRequest> query = entityManager.createQuery("SELECT S FROM SellerRequest S WHERE S.bondName = :bondName", SellerRequest.class);
        query.setParameter("bondName", bondName);
        List<SellerRequest> list = query.getResultList();
        return list;
    }
}

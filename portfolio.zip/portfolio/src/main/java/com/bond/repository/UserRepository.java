package com.bond.repository;

import com.bond.entities.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class UserRepository {
    Logger logger = LoggerFactory.getLogger(UserRepository.class);
    @Autowired
    private EntityManager entityManager;

    public User findByUserId(String userName) {
        TypedQuery<User> query = null;
        User user = null;
        try {
            query = entityManager.createQuery("SELECT u FROM User u WHERE u.userName = :userName", User.class);
            query.setParameter("userName", userName);
            user = query.getSingleResult();
            if (null == user) {
                logger.info("user with id {} not found", userName);
            }
        } catch (Exception e) {
            logger.error(e.getStackTrace().toString());
        }
        return user;
    }

    @Transactional
    public User add(User user) {
        entityManager.persist(user);
        return user;
    }

    public List<User> getCustomer(String bondName) {
        Query query = entityManager.createNativeQuery("SELECT * FROM user u WHERE u.user_name IN (SELECT DISTINCT buyer_name FROM customer_portfolio WHERE bond_name = :bondName)", User.class);
        query.setParameter("bondName", bondName);
        List<User> list = query.getResultList();
        return list;
    }
}

package com.bond.repository;

import com.bond.entities.CustomerPortfolio;
import com.bond.entities.SalesInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class CustomerPortfolioRepository {
    @Autowired
    EntityManager entityManager;

    @Transactional
    public CustomerPortfolio add(CustomerPortfolio customerPortfolio) {
        entityManager.persist(customerPortfolio);
        return customerPortfolio;
    }

    public List<CustomerPortfolio> get(String customerName) {
        TypedQuery<CustomerPortfolio> query = entityManager.createQuery("SELECT C FROM CustomerPortfolio C WHERE C.buyerName = :customerName", CustomerPortfolio.class);
        query.setParameter("customerName", customerName);
        return query.getResultList();
    }
}

package com.bond.entities;

import javax.persistence.*;

/**
 * there are three types of users "ADMIN", "CUSTOMER", "SELLER"
 */
@Entity
@Table(name="USER", uniqueConstraints={@UniqueConstraint(columnNames ={"user_name", "email"})})
public class User {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private long id;

    @Column(name="user_name")
    private String userName;

    private String name;

    private String email;

    private String role;

    public User() {

    }

    public User(String userName, String name, String email, String role) {
        this.userName = userName;
        this.name = name;
        this.email = email;
        this.role = role;
    }

    public long getId() {
        return id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}

package com.bond.entities;

import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Keeps track when sales happen
 */
@Entity
public class SalesInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name="bond_name", nullable = false)
    private String bondName;

    @Column(name="buyer", nullable = false)
    private String buyer;

    @Column(name="seller", nullable = false)
    private String seller;

    @Column(name="count", nullable = false)
    private int count;

    @Column(name="price", nullable = false)
    private double price;

    @CreationTimestamp
    private LocalDateTime created;

    public SalesInfo() {

    }

    public SalesInfo(String bondName, String buyer, String seller, int count, double price) {
        this.bondName = bondName;
        this.buyer = buyer;
        this.seller = seller;
        this.count = count;
        this.price = price;
    }

    public String getBondName() {
        return bondName;
    }

    public void setBondName(String bondName) {
        this.bondName = bondName;
    }

    public String getBuyer() {
        return buyer;
    }

    public void setBuyer(String buyer) {
        this.buyer = buyer;
    }

    public String getSeller() {
        return seller;
    }

    public void setSeller(String seller) {
        this.seller = seller;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public long getId() {
        return id;
    }

    public LocalDateTime getCreated() {
        return created;
    }
}

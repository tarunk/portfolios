package com.bond.entities;

import com.bond.requests.BondRequest;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Bond Entity
 */
@Entity
@Table(name="BOND", uniqueConstraints={@UniqueConstraint(columnNames ={"bond_name"})})
public class Bond {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private long id;

    @Column(name="bond_name", unique = true, length = 25)
    private String bondName;

    @Column(name="description", length = 100)
    private String description;

    private double price;

    @Column(name="avg_return")
    private double avgReturn;

    @Column(name="profit_prediction")
    private double profitPrediction;

    @UpdateTimestamp
    private LocalDateTime updated;

    @CreationTimestamp
    private LocalDateTime created;

    public Bond() {

    }

    public Bond(BondRequest bondRequest) {
        this.bondName = bondRequest.getBondName();
        this.description = bondRequest.getDescription();
        this.price = bondRequest.getPricing();
        this.avgReturn = bondRequest.getAvgReturn();
        this.profitPrediction = bondRequest.getProfitPre();
    }

    public String getBondName() {
        return bondName;
    }

    public void setBondName(String bondName) {
        this.bondName = bondName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getAvgReturn() {
        return avgReturn;
    }

    public void setAvgReturn(double avgReturn) {
        this.avgReturn = avgReturn;
    }

    public double getProfitPrediction() {
        return profitPrediction;
    }

    public void setProfitPrediction(double profitPrediction) {
        this.profitPrediction = profitPrediction;
    }

    public LocalDateTime getUpdated() {
        return updated;
    }

    public void setUpdated(LocalDateTime updated) {
        this.updated = updated;
    }

    public LocalDateTime getCreated() {
        return created;
    }

    public void setCreated(LocalDateTime created) {
        this.created = created;
    }

    public long getId() {
        return this.id;
    }
}

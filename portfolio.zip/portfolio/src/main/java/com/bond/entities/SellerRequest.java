package com.bond.entities;

import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name="SELLER_REQUEST")
public class SellerRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    long id;

    @Column(name="seller", nullable = false)
    private String seller;

    @Column(name="bond_name", nullable = false)
    private String bondName;

    @Column(name="count", nullable = false)
    private int count;

    @Column(name="sell_price", nullable = false)
    private double sellPrice;

    @Column(name="status", nullable = false)
    private String status;

    @CreationTimestamp
    public LocalDateTime created;

    public SellerRequest() {

    }

    public SellerRequest(String seller, String bondName, int count, double sellPrice) {
        this.seller = seller;
        this.bondName = bondName;
        this.count = count;
        this.sellPrice = sellPrice;
        this.status = "PENDING";
    }

    public String getSeller() {
        return seller;
    }

    public void setSeller(String seller) {
        this.seller = seller;
    }

    public String getBondName() {
        return bondName;
    }

    public void setBondId(String bondName) {
        this.bondName = bondName;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public double getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(double sellPrice) {
        this.sellPrice = sellPrice;
    }

    public long getId() {
        return id;
    }

    public LocalDateTime getCreated() {
        return created;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

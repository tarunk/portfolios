package com.bond.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * For tracking the bond and its owner
 */
@Entity
@Table(name = "bond_owner")
public class BondOwner implements Serializable {
    @Id
    @Column(name="customer")
    private String owner;

    @Id
    @Column(name = "bond_name")
    private String bondName;

    private int count;

    public BondOwner() {

    }

    public BondOwner(String owner, String bondName, int count) {
        this.owner = owner;
        this.bondName = bondName;
        this.count = count;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getBondName() {
        return bondName;
    }

    public void setBondName(String bondName) {
        this.bondName = bondName;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}

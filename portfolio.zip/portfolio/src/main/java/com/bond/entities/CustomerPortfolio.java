package com.bond.entities;

import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Tracks Buyers portfolios
 */
@Entity
public class CustomerPortfolio {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name="buyer_name", nullable = false)
    private String buyerName;

    @Column(name="seller_name")
    private String sellerName;

    @Column(name="bond_name", nullable = false)
    private String bondName;

    @Column(name="count", nullable = false)
    private int count;

    @Column(name="price", nullable = false)
    private double price;

    @CreationTimestamp
    private LocalDateTime created;

    public CustomerPortfolio() {

    }

    public CustomerPortfolio(String buyerName, String sellerName, String bondName, int count, double price) {
        this.buyerName = buyerName;
        this.sellerName = sellerName;
        this.bondName = bondName;
        this.count = count;
        this.price = price;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getBondName() {
        return bondName;
    }

    public void setBondName(String bondName) {
        this.bondName = bondName;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public long getId() {
        return id;
    }

    public LocalDateTime getCreated() {
        return created;
    }
}

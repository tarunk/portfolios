package com.bond.entities;

import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * This track Buyer's request
 */
@Entity
@Table(name="BUYER_REQUEST")
public class BuyerRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    long id;

    @Column(name="buyer", nullable = false)
    private String buyer;

    @Column(name="bond_name", nullable = false)
    private String bondName;

    private int count;

    private String status;

    @CreationTimestamp
    public LocalDateTime created;
    public BuyerRequest() {

    }
    public BuyerRequest(String buyer, String bondName, int count, double buyPrice) {
        this.bondName = bondName;
        this.buyer = buyer;
        this.count = count;
        this.status = "PENDING";
    }

    public String getBuyer() {
        return buyer;
    }

    public void setBuyer(String buyer) {
        this.buyer = buyer;
    }

    public String getBondName() {
        return bondName;
    }

    public void setBondId(String bondName) {
        this.bondName = bondName;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public long getId() {
        return id;
    }

    public LocalDateTime getCreated() {
        return created;
    }

    public void setBondName(String bondName) {
        this.bondName = bondName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

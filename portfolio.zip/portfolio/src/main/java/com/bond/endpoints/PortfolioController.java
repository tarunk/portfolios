package com.bond.endpoints;

import com.bond.entities.*;
import com.bond.repository.*;
import com.bond.responses.BuyerPortfolioRecord;
import com.bond.responses.SalesPersonRecord;
import com.bond.services.BuyRequestManager;
import com.bond.services.SaleRequestManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController()
@RequestMapping("/bond")
public class PortfolioController {
    @Autowired
    BuyRequestManager buyRequestManager;

    @Autowired
    SaleRequestManager saleRequestManager;

    @Autowired
    BuyerRepository buyerRepository;

    @Autowired
    SellerRepository sellerRepository;

    @Autowired
    SalesInfoRepository salesInfoRepository;

    @Autowired
    BondRepository bondRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    CustomerPortfolioRepository customerPortfolioRepository;

    @Autowired
    BondOwnerRepository bondOwnerRepository;

    @PostMapping(value = "/buyer/portfolios")
    public ResponseEntity<BuyerRequest> addBuyRequest(@RequestBody BuyerRequest buyerRequest) {
        User user = userRepository.findByUserId(buyerRequest.getBuyer());
        Bond bond = bondRepository.get(buyerRequest.getBondName());
        if (user == null || bond == null || !user.getRole().equals("CUSTOMER")) {
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(null);
        }
        buyerRequest.setStatus("PENDING");
        BuyerRequest buyerRequest1 = buyerRepository.add(buyerRequest);
        buyRequestManager.add(buyerRequest1);
        return ResponseEntity.status(HttpStatus.CREATED).body(buyerRequest);
    }

    @PostMapping(value = "/seller/portfolios")
    public ResponseEntity<SellerRequest> addSellRequest(@RequestBody SellerRequest sellerRequest) {
        User user = userRepository.findByUserId(sellerRequest.getSeller());
        Bond bond = bondRepository.get(sellerRequest.getBondName());
        if (user == null || bond == null || !(user.getRole().equals("CUSTOMER") || user.getRole().equals("SELLER"))) {
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(null);
        }
        if (user.getRole().equals("CUSTOMER")) {
            BondOwner bondOwner = bondOwnerRepository.get(sellerRequest.getSeller(), sellerRequest.getBondName());
            if (bondOwner == null || bondOwner.getCount() < sellerRequest.getCount()) {
                return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(null);
            } else {
                bondOwner.setCount(bondOwner.getCount() - sellerRequest.getCount());
                bondOwnerRepository.update(bondOwner);
            }
        }
        sellerRequest.setStatus("PENDING");
        SellerRequest sellerRequest1 = sellerRepository.add(sellerRequest);
        saleRequestManager.add(sellerRequest1);
        return ResponseEntity.status(HttpStatus.CREATED).body(sellerRequest1);
    }

    @GetMapping(value = "/sales/seller/{seller}")
    public ResponseEntity<List<SalesPersonRecord>> getSalesInfo(@PathVariable("seller") String seller) {
        User user = userRepository.findByUserId(seller);
        if (user == null || !user.getRole().equals("SELLER")) {
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(null);
        }
        List<SalesInfo> list = salesInfoRepository.getSellers(seller);
        List<SalesPersonRecord> salesRecords = new ArrayList<>();
        for (SalesInfo salesInfo : list) {
            Bond bond = bondRepository.get(salesInfo.getBondName());
            User buyer = userRepository.findByUserId(salesInfo.getBuyer());
            SalesPersonRecord salesPersonRecord = new SalesPersonRecord(salesInfo, bond, buyer);
            salesRecords.add(salesPersonRecord);
        }
        return ResponseEntity.ok(salesRecords);
    }

    @GetMapping(value = "/portfolios/customer/{customerName}")
    public ResponseEntity<List<BuyerPortfolioRecord>> getBuyerPortfolios(@PathVariable("customerName") String customerName) {
        User user = userRepository.findByUserId(customerName);
        if (user == null || !user.getRole().equals("CUSTOMER")) {
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(null);
        }
        List<CustomerPortfolio> customerPortfolios = customerPortfolioRepository.get(customerName);
        List<BuyerPortfolioRecord> buyerPortfolioRecords = new ArrayList<>();
        for (CustomerPortfolio customerPortfolio : customerPortfolios) {
            Bond bond = bondRepository.get(customerPortfolio.getBondName());
            User seller = userRepository.findByUserId(customerPortfolio.getSellerName());
            buyerPortfolioRecords.add(new BuyerPortfolioRecord(bond, seller, customerPortfolio));
        }
        return ResponseEntity.ok(buyerPortfolioRecords);
    }
}

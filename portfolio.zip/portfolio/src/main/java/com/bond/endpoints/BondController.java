package com.bond.endpoints;

import com.bond.entities.Bond;
import com.bond.entities.SalesInfo;
import com.bond.entities.User;
import com.bond.reports.GeneratePdfReport;
import com.bond.repository.*;
import com.bond.requests.BondRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayInputStream;
import java.util.List;


@RestController
@RequestMapping(value="/api")
public class BondController {
    Logger logger = LoggerFactory.getLogger(BondController.class);
    @Autowired
    UserRepository userRepository;

    @Autowired
    BondRepository bondRepository;

    @Autowired
    BuyerRepository buyerRepository;

    @Autowired
    SellerRepository sellerRepository;

    @Autowired
    SalesInfoRepository salesInfoRepository;

    /**
    @GetMapping(value="/hello")
    public ResponseEntity<List<Bond>> sayHello() {
        List<Bond> bonds = bondRepository.getBond("tonu");
        return ResponseEntity.ok(bonds);
    }
    */

    @GetMapping(value="/customers/bond/{bondName}/{admin}")
    public ResponseEntity<List<User>> getCustomersOfBond(@PathVariable("bondName") String bondName, @PathVariable("admin") String admin) {
        if (!isAdmin(admin)) {
            logger.error("Client[ {} ]not authorized to get Customer details", admin);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        List<User> users = userRepository.getCustomer(bondName);
        return ResponseEntity.ok(users);
    }

    @GetMapping(value="/bonds/customer/{customerName}/{admin}")
    public ResponseEntity<List<Bond>> getBondsOfCustomer(@PathVariable("customerName") String customerName, @PathVariable("admin") String admin) {
        if (!isAdmin(admin)) {
            logger.error("Client[ {} ]not authorized to get Customer details", admin);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        List<Bond> bonds = bondRepository.getBond(customerName);
        return ResponseEntity.ok(bonds);
    }

    @PostMapping(value="/bonds")
    public ResponseEntity<Bond> addBond(@RequestBody BondRequest bondRequest) {
        if (!isAdmin(bondRequest.getUserId())) {
            logger.error("Client[ {} ]not authorized for add bond", bondRequest.getUserId());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        Bond bond = bondRepository.add(bondRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(bond);
    }

    @PutMapping(value="/bonds")
    public ResponseEntity<Bond> updateBond(@RequestBody BondRequest bondRequest) {
        if (!isAdmin(bondRequest.getUserId()) || !isValidBond(bondRequest.getBondName())) {
            logger.error("Client[ {} ]not authorized to modify bond", bondRequest.getUserId());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        Bond bond = bondRepository.update(bondRequest);
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(bond);
    }

    @DeleteMapping(value="/bonds/{bondName}")
    public ResponseEntity<Bond> deleteBond(@RequestBody BondRequest bondRequest, @PathVariable String bondName) {
        if (!isAdmin(bondRequest.getUserId()) || !isValidBond(bondName)) {
            logger.error("Client[ {} ]not authorized to delete bond", bondRequest.getUserId());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        Bond bond = null;
        if (sellerRepository.getSellerRequest(bondName).size() == 0 && buyerRepository.getBuyerRequest(bondName).size() == 0) {
            bond = bondRepository.delete(bondName);
        }
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(bond);
    }

    @GetMapping(value="/report/{frq}/{admin}", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<InputStreamResource> salesReport(@PathVariable("frq") String frq, @PathVariable("admin") String admin) {
        if (!isAdmin(admin)) {
            return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(null);
        }
        List<SalesInfo> salesInfos = salesInfoRepository.getSalesReport(frq.toLowerCase());
        //generate report
        ByteArrayInputStream byteArrayInputStream = GeneratePdfReport.getReport(salesInfos);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "inline; filename=salesReport.pdf");
        return ResponseEntity.ok().headers(headers)
                .contentType(MediaType.APPLICATION_PDF).
                        body(new InputStreamResource(byteArrayInputStream));
    }

    boolean isAdmin(String adminId) {
        try {
            User user = userRepository.findByUserId(adminId);
            if (user != null && user.getRole().equals("ADMIN")) {
                return true;
            }
        } catch (Exception e) {
            logger.error(e.getStackTrace().toString());
        }
        return false;
    }

    boolean isValidBond(String bondName) {
        Bond bond = bondRepository.get(bondName);
        if (bond == null) {
            return false;
        }
        return true;
    }
}

package com.bond.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Component;

@Configuration
public class ExecutorConfig {
    @Bean
    public ThreadPoolTaskScheduler myPortfolioExecutor() {
        ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
        threadPoolTaskScheduler.setPoolSize(5);
        threadPoolTaskScheduler.setThreadNamePrefix("PortfolioExecutor-");
        threadPoolTaskScheduler.initialize();
        return threadPoolTaskScheduler;
    }
}

package com.bond.requests;

/**
 * Request to create and update bond
 */
public class BondRequest {
    private String userId;
    private String bondName;
    private String description;
    private double pricing;
    private double avgReturn;
    private double profitPre;

    public BondRequest() {

    }
    public BondRequest(String userId, String bondName, String des,
                       double pricing, double avgReturn, double profitPre) {
        this.userId = userId;
        this.bondName = bondName;
        this.description = des;
        this.pricing = pricing;
        this.avgReturn = avgReturn;
        this.profitPre = profitPre;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBondName() {
        return bondName;
    }

    public void setBondName(String bondName) {
        this.bondName = bondName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPricing() {
        return pricing;
    }

    public void setPricing(double pricing) {
        this.pricing = pricing;
    }

    public double getAvgReturn() {
        return avgReturn;
    }

    public void setAvgReturn(double avgReturn) {
        this.avgReturn = avgReturn;
    }

    public double getProfitPre() {
        return profitPre;
    }

    public void setProfitPre(double profitPre) {
        this.profitPre = profitPre;
    }
}

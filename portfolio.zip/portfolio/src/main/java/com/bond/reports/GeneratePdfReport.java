package com.bond.reports;


import com.bond.entities.SalesInfo;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

/**
 * Generates PDF reports
 */
public class GeneratePdfReport {
    private static Logger logger = LoggerFactory.getLogger(GeneratePdfReport.class);
    public static ByteArrayInputStream getReport(java.util.List<SalesInfo> salesInfoList) {
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            PdfPTable pdfPTable = new PdfPTable(7);
            pdfPTable.setWidthPercentage(95);
            pdfPTable.setWidths(new int[] {1, 4, 2, 2, 2, 2, 6});
            String [] HEADS = {"ID", "BOND", "BUYER", "SELLER", "COUNT", "PRICE", "TIME"};

            Font headFont = FontFactory.getFont(FontFactory.COURIER, 11);
            for (String HEAD : HEADS) {
                PdfPCell hcell = new PdfPCell(new Phrase(HEAD, headFont));
                hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
                pdfPTable.addCell(hcell);
            }

            for (SalesInfo salesInfo : salesInfoList) {
                PdfPCell cell;

                cell = new PdfPCell(new Phrase(Long.toString(salesInfo.getId())));
                cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                pdfPTable.addCell(cell);

                cell = new PdfPCell(new Phrase(salesInfo.getBondName()));
                cell.setPaddingLeft(1);
                cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cell.setHorizontalAlignment(Element.ALIGN_LEFT);
                pdfPTable.addCell(cell);

                cell = new PdfPCell(new Phrase(salesInfo.getBuyer()));
                cell.setPaddingLeft(1);
                cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cell.setHorizontalAlignment(Element.ALIGN_LEFT);
                pdfPTable.addCell(cell);

                cell = new PdfPCell(new Phrase(salesInfo.getSeller()));
                cell.setPaddingLeft(1);
                cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cell.setHorizontalAlignment(Element.ALIGN_LEFT);
                pdfPTable.addCell(cell);

                cell = new PdfPCell(new Phrase(Integer.toString(salesInfo.getCount())));
                cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
                pdfPTable.addCell(cell);

                cell = new PdfPCell(new Phrase(Double.toString(salesInfo.getPrice())));
                cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
                pdfPTable.addCell(cell);

                cell = new PdfPCell(new Phrase(salesInfo.getCreated().toString()));
                cell.setPaddingLeft(1);
                cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cell.setHorizontalAlignment(Element.ALIGN_LEFT);
                pdfPTable.addCell(cell);
            }
            PdfWriter.getInstance(document, out);
            document.open();
            document.add(pdfPTable);
            document.close();
        } catch (Exception e) {
            logger.error("Error occurred: {0}", e);
        }
        return new ByteArrayInputStream(out.toByteArray());
    }
}

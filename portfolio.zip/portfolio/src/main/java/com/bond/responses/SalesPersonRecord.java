package com.bond.responses;


import com.bond.entities.Bond;
import com.bond.entities.SalesInfo;
import com.bond.entities.User;

public class SalesPersonRecord {
    private Bond bondInfo;
    private User customerInfo;
    private SalesInfo salesInfo;

    public SalesPersonRecord(SalesInfo salesInfo, Bond bond, User customerInfo) {
        this.salesInfo = salesInfo;
        this.bondInfo = bond;
        this.customerInfo = customerInfo;
    }

    public Bond getBondInfo() {
        return bondInfo;
    }

    public void setBondInfo(Bond bondInfo) {
        this.bondInfo = bondInfo;
    }

    public User getCustomerInfo() {
        return customerInfo;
    }

    public void setCustomerInfo(User customerInfo) {
        this.customerInfo = customerInfo;
    }

    public SalesInfo getSalesInfo() {
        return salesInfo;
    }

    public void setSalesInfo(SalesInfo salesInfo) {
        this.salesInfo = salesInfo;
    }
}

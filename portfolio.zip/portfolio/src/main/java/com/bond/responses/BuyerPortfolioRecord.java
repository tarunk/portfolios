package com.bond.responses;

import com.bond.entities.Bond;
import com.bond.entities.CustomerPortfolio;
import com.bond.entities.User;

public class BuyerPortfolioRecord {
    private Bond bondInfo;
    private User salesPersonInfo;
    private CustomerPortfolio customerPortfolio;

    public BuyerPortfolioRecord (Bond bondInfo, User salesPersonInfo, CustomerPortfolio customerPortfolio) {
        this.bondInfo = bondInfo;
        this.salesPersonInfo = salesPersonInfo;
        this.customerPortfolio = customerPortfolio;
    }

    public Bond getBondInfo() {
        return bondInfo;
    }

    public void setBondInfo(Bond bondInfo) {
        this.bondInfo = bondInfo;
    }

    public User getSalesPersonInfo() {
        return salesPersonInfo;
    }

    public void setSalesPersonInfo(User salesPersonInfo) {
        this.salesPersonInfo = salesPersonInfo;
    }

    public CustomerPortfolio getCustomerPortfolio() {
        return customerPortfolio;
    }

    public void setCustomerPortfolio(CustomerPortfolio customerPortfolio) {
        this.customerPortfolio = customerPortfolio;
    }
}
